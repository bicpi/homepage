<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Prepared Statements 3</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// preparedstatements3.php
$mysqli = new mysqli('DBHost', 'DBBenutzer', 'DBPasswort', 'DBName');
if(mysqli_connect_errno())
   die('MySQL-Verbindung fehlgeschlagen: ' .  mysqli_connect_error());

$sql = "SELECT Vorname, Nachname, Gehalt
        FROM mitarbeiter
        WHERE Gehalt > ?";
if($stmt = $mysqli->prepare($sql)){
  $stmt->bind_param('i', $gehalt);

  $gehalt = 3000;
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($vorname, $nachname, $gehalt);
  while($stmt->fetch())
    echo "$vorname $nachname $gehalt<br />";

  echo '<br />-----------<br />';
  $gehalt = 4000;
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($vorname, $nachname, $gehalt);
  while($stmt->fetch())
    echo "$vorname $nachname $gehalt<br />";

  $stmt->close();
}

$mysqli->close();
?>
</body>
</html>
