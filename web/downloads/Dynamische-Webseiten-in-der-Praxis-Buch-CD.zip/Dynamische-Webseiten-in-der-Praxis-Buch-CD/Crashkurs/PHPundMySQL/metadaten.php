<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Metadaten einer Ergebnisresource abfragen</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// metadaten.php
$mysqli = new mysqli('DBHost', 'DBBenutzer', 'DBPasswort', 'DBName');
if(mysqli_connect_errno())
   die('MySQL-Verbindung fehlgeschlagen: ' .  mysqli_connect_error());

$sql = "SELECT *
        FROM statistik1";
$ergebnis = $mysqli->query($sql);
$metainfos = $ergebnis->fetch_fields();
foreach($metainfos as $info){
  echo "Tabelle: $info->table <br />
        Spaltenname: $info->name <br/>
        Max. Spaltenl&auml;nge: {$info->max_length} <br />
        Datentyp: $info->type <br />
        Defaultwert: $info->def <br />
        ----------------------------------------------<br />";
}

$mysqli->close();
?>
</body>
</html>
