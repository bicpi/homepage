<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Abfragen ausf&uuml;hren - query</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// mysqliquery.php
$mysqli = new mysqli('DBHost', 'DBBenutzer', 'DBPasswort', 'DBName');
if(mysqli_connect_errno())
   die('MySQL-Verbindung fehlgeschlagen: ' .  mysqli_connect_error());
   
$sql = 'CREATE TABLE IF NOT EXISTS mitarbeiter(
          ID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
          Vorname VARCHAR(100),
          Nachname VARCHAR(100),
          Gehalt INT
        )';
$mysqli->query($sql);
$sql = "INSERT INTO mitarbeiter (Vorname, Nachname, Gehalt)
        VALUES ('Peter', 'Kupfer', '2687')";
$mysqli->query($sql);

$mysqli->close();
?>
</body>
</html>
