<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>multi_query 3</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// multiquery3.php
$mysqli = new mysqli('DBHost', 'DBBenutzer', 'DBPasswort', 'DBName');
if(mysqli_connect_errno())
   die('MySQL-Verbindung fehlgeschlagen: ' .  mysqli_connect_error());

$sql = "INSERT INTO mitarbeiter (Vorname, Nachname, Gehalt)
        VALUES ('Janna', 'Reiser', '3920');
        SELECT Nachname FROM mitarbeiter;
        SELECT Vorname, Nachname, Gehalt
        FROM mitarbeiter;
        UPDATE mitarbeiter
        SET Gehalt = '3900'
        WHERE id = LAST_INSERT_ID()";
$mysqli->multi_query($sql);
$mysqli->next_result();
$ergebnis = $mysqli->store_result();
while($daten = $ergebnis->fetch_row()) {
  echo $daten[0] . '<br />';
}
echo '<hr />';
$ergebnis->close();

$mysqli->next_result();
$ergebnis = $mysqli->store_result();
while($daten = $ergebnis->fetch_object()) {
  echo "$daten->Vorname $daten->Nachname $daten->Gehalt <br />";
}

$mysqli->close();
?>
</body>
</html>
