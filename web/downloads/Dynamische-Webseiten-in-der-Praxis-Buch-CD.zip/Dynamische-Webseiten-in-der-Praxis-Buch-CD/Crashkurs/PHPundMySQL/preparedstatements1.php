<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Prepared Statements 1</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// preparedstatements1.php
$mysqli = new mysqli('DBHost', 'DBBenutzer', 'DBPasswort', 'DBName');
if(mysqli_connect_errno())
   die('MySQL-Verbindung fehlgeschlagen: ' .  mysqli_connect_error());

$sql = "INSERT INTO mitarbeiter (Vorname, Nachname, Gehalt)
        VALUES (?, ?, ?)";
if($stmt = $mysqli->prepare($sql)){
  $stmt->bind_param('ssi', $vorname, $nachname, $gehalt);

  $vorname  = 'Alix';
  $nachname = 'von Weinbauer';
  $gehalt   = 4123;
  $stmt->execute();

  $vorname  = 'Flo';
  $nachname = 'Kahlert';
  $gehalt   = 3082;
  $stmt->execute();

  echo 'Betroffene Datens&auml;tze: ' . $stmt->affected_rows . '<br />';
  echo 'Letzte ID: ' . $mysqli->insert_id;

  $stmt->close();
}

$mysqli->close();
?>
</body>
</html>
