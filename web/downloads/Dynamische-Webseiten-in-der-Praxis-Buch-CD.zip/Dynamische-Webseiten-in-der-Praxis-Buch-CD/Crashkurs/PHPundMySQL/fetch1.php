<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Daten verarbeiten 1</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// fetch1.php
$mysqli = new mysqli('DBHost', 'DBBenutzer', 'DBPasswort', 'DBName');
if(mysqli_connect_errno())
   die('MySQL-Verbindung fehlgeschlagen: ' .  mysqli_connect_error());

$sql = "SELECT Vorname, Nachname, Gehalt
        FROM mitarbeiter";
$ergebnis = $mysqli->query($sql);
while($daten = $ergebnis->fetch_object()){
  echo "Vorname: $daten->Vorname <br />
        Nachname: $daten->Nachname <br />
        Gehalt: $daten->Gehalt <br />
        -----------------------------------<br />";
}
echo "Anzahl Datens&auml;tze: $ergebnis->num_rows <br />
      Anzahl Spalten: $ergebnis->field_count";

$mysqli->close();
?>
</body>
</html>
