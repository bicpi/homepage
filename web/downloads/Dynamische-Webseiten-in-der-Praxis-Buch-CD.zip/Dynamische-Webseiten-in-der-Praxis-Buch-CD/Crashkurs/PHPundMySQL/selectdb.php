<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Datenbank auw&auml;hlen - select_db</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// selectdb.php
$mysqli = new mysqli('DBHost', 'DBBenutzer', 'DBPasswort', 'DBName');
if(mysqli_connect_errno())
   die('MySQL-Verbindung fehlgeschlagen: ' .  mysqli_connect_error());
   
$mysqli->select_db('kinofilme');
if ($result = $mysqli->query('SELECT DATABASE()')) {
   $row = $result->fetch_row();
   echo "Akuelle Datenbank: $row[0]<br />";
   $result->close();
}
$mysqli->select_db('mysqli');
if ($result = $mysqli->query('SELECT DATABASE()')) {
   $row = $result->fetch_row();
   echo "Akuelle Datenbank: $row[0]";
   $result->close();
}

$mysqli->close();
?>
</body>
</html>
