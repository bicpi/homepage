<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>multi_query 1</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// multiquery1.php
$mysqli = new mysqli('DBHost', 'DBBenutzer', 'DBPasswort', 'DBName');
if(mysqli_connect_errno())
   die('MySQL-Verbindung fehlgeschlagen: ' .  mysqli_connect_error());

$sql = "INSERT INTO mitarbeiter (Vorname, Nachname, Gehalt)
        VALUES ('Alfred', 'Heidenegger', '4217');
        INSERT INTO mitarbeiter (Vorname, Nachname, Gehalt)
        VALUES ('Beate', 'Catalia', '3129');
        UPDATE mitarbeiter
        SET gehalt = '3500'
        WHERE id = LAST_INSERT_ID()";

if($ergebnis = $mysqli->multi_query($sql))
  echo 'Erste Abfrage erfolgreich.';
else
  echo 'Erste Abfrage gescheitert: ' . $mysqli->error;

$mysqli->close();
?>
</body>
</html>
