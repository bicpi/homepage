<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>multi_query 2</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// multiquery2.php
$mysqli = new mysqli('DBHost', 'DBBenutzer', 'DBPasswort', 'DBName');
if(mysqli_connect_errno())
   die('MySQL-Verbindung fehlgeschlagen: ' .  mysqli_connect_error());

$sql = "SELECT Gehalt 
        FROM mitarbeiter;
        SELECT Nachname 
        FROM mitarbeiter;
        SELECT Vorname 
        FROM mitarbeiter";
$mysqli->multi_query($sql);
do{
  if($ergebnis = $mysqli->store_result()){
    while($daten = $ergebnis->fetch_row()) {
      echo $daten[0] . '<br />';
    }
    $ergebnis->close();
  }
  if($mysqli->more_results()){
    echo '<br />';
  }
}
while($mysqli->next_result());

$mysqli->close();
?>
</body>
</html>
