<?php
header('Content-Type: text/html;charset=utf-8');
$navigation = array(
  1 => array(
    'header'  => 'Header 1',
    'bgColor' => '#99CCFF',
    'content' => 'Content 1',
  ),
  2 => array(
    'header'  => 'Header 2',
    'bgColor' => '#FF6666',    
    'content' => 'Content 2',
  ),
  3 => array(
    'header'  => 'Header 3',
    'bgColor' => '#CCCC99',    
    'content' => 'Content 3'
  ),      
);
$id = (int)$_GET['id'];
if(!isset($navigation[$id])){
  $id = 1;
}
$result = $navigation[$id];
$result['id'] = $id;
echo json_encode($result);