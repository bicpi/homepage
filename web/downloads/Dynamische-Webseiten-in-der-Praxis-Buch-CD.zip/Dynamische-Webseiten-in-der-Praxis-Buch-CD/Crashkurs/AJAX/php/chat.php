<?php
header('Content-Type: text/html;charset=utf-8');
$filepath = '../data/chat.txt';
$content = file_get_contents($filepath);
if(isset($_POST['msg'])){
  $content = $_POST['msg'] . "\n" . $content;
  file_put_contents($filepath, $content);
}
echo nl2br(htmlspecialchars($content));