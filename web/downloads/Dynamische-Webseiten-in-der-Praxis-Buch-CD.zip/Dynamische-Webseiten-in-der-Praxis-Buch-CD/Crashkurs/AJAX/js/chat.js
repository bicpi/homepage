function byId(id){
  return document.getElementById(id);
}

var Chat = {
  msg: false,
  init: function(){
    window.setInterval('Chat.update()', 1000);
    byId('chat_form').onsubmit = Chat.sendMsg;
  },
  sendMsg: function(){
    Chat.msg = byId('message').value;
    byId('message').value = '';
    return false;
  },
  update: function(){
    with(new AjaxEngine()){
      url = 'php/chat.php';
      method = 'post';
      params = (Chat.msg !== false) ? 'msg=' + encodeURIComponent(Chat.msg) : '';
      successHandler = Chat.handleUpdate;
      sendRequest();
    }
    Chat.msg = false;    
  },
  handleUpdate: function(responseText, responseXML){
    byId('chatbox').innerHTML = responseText;
  }
};

window.onload = Chat.init;

