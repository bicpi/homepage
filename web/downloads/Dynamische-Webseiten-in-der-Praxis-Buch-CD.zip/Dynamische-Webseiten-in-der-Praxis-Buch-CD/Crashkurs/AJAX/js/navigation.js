function byId(id){
  return document.getElementById(id);
}

var Navigation = {
  init: function(){
    for(var id = 1; id <= 3; id++){
      byId('link_'+id).onclick = Navigation.getPage;
    }
    Navigation.getPage();
  },
  getPage: function(){
    var id = (this.id) ? parseInt(this.id.match(/.*_([\d])$/)[1]) : 1;
    with(new AjaxEngine()){
      url = 'php/navigation.php';
      params = 'id=' + id;
      successHandler = Navigation.handleResult;
      sendRequest();
    }
    return false;    
  },
  handleResult: function(responseText, responseXML){
    var result = JSON.parse(responseText);
    var h = byId('header'); var f = byId('footer');
    h.innerHTML = result.header; h.style.backgroundColor = result.bgColor;
    byId('content').innerHTML = result.content;
    f.innerHTML = result.footer; f.style.backgroundColor = result.bgColor;
    var n = byId('navigation');
    for(var i = 0; i < n.childNodes.length; ++i){
      if(n.childNodes[i].nodeName == 'A'){
        n.childNodes[i].style.fontWeight = 'normal';
      }
    }
    byId('link_'+result.id).style.fontWeight = 'bold';
  }
};

window.onload = Navigation.init;
