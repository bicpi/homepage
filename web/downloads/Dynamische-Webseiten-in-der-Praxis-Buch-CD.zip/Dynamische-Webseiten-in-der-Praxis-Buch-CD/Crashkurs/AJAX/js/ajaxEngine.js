// ajaxEngine.js

// Funktion zur Beschaffung eines XMLHttpRequest-Objekts
function getXMLHttpRequest(){
  // XMLHttpRequest-Objekt fuer alle Browser ausser IE < 7 erzeugen
  if(window.XMLHttpRequest){
    return new XMLHttpRequest();
  }
  // XMLHttpRequest-Objekt fuer IE < 7 erzeugen
  if(window.ActiveXObject){
    try{
      // Fr IE 6
      return new ActiveXObject("Msxml2.XMLHTTP");
    }
    catch(exception){
      try{
        // Fr IE 5.x
        return new ActiveXObject("Microsoft.XMLHTTP")
      }
      catch(exception){}
    }
  }
  // Browser unterstuetzt kein XMLHttpRequest
  errorMsg = "Ihr Browser unterstuetzt leider kein AJAX. Bitte aktualisieren Sie Ihren Browser, um alle Funktionen dieser Website nutzen zu koennen.";
  alert(errorMsg);
  return null;
}

// Klasse der Ajax-Engine
function AjaxEngine(){
  this.url = '';                   // Request-URL
  this.method = 'GET';             // Request-Methode
  this.params = '';                // Request-Parameter
  this.errorHandler = function(errorMsg){
    alert(errorMsg);
  }; // Fehlerfunktion
  /* Funktion, die nach erfolgreicher Response ausgefuehrt werden soll.
     Zu diesem Zeitpunkt noch unbekannt, deshalb 'null'. */
  this.successHandler = null;
  // Standard-Fehlerfunktion; gibt Fehlermeldung als Alert aus

}

// Methode, um Request abzusetzen
AjaxEngine.prototype.sendRequest = function(){
  // Ohne Request-URL kann kein Request-URL abgesetzt werden
  if(!this.url){
    this.errorHandler('Kein URL fr den AJAX-Request angegeben.');
    return null;
  }
  // Request-Methode muss gross geschrieben sein
  this.method = this.method.toUpperCase();
  // Als Request-Methode ist nur GET und POST zulaessig
  if(this.method != 'GET' && this.method != 'POST'){
    this.method = 'GET';
  }
  /* Referenz auf die eigene Klasse erzeugen, um sie weiter unten
     in der Methode 'readyStateHandler' verwenden zu koennen */
  var _this = this;
  // XMLHttpRequest-Objekt fuer den AJAX-Request erzeugen
  var xmlHttpRequest = getXMLHttpRequest();
  // Ohne XMLHttpRequest-Objekt kein Ajax-Request
  if(!xmlHttpRequest){
    this.errorHandler('XMLHttpRequest-Objekt fr AJAX-Abfrage konnte nicht erstellt werden.')
    return null;
  }
  // Request je nach Methode (GET, POST) absetzen
  if(this.method == 'GET'){
    // Bei GET stehen die Parameter im URL
    xmlHttpRequest.open(this.method, this.url + '?' + this.params, true);
    /* Aendert sich der readyState des Requests, wird die weiter unten definierte Methode
       'responseHandler' aufgerufen */
    xmlHttpRequest.onreadystatechange = responseHandler;
    // Request senden
    xmlHttpRequest.send(null);
  }
  else{
    // Bei POST stehen keine Parameter im URL
    xmlHttpRequest.open(this.method, this.url, true);
    xmlHttpRequest.onreadystatechange = responseHandler;
    /* Ein POST-Request muss mit dem gleichen Content-Type wie ein
       Formulars bertragen werden: 'application/x-www-form-urlencoded' */
    xmlHttpRequest.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    // Die POST-Parameter werden erst bei der 'send'-Methode bergeben
    xmlHttpRequest.send(this.params);
  }

  // Methode, die bei jedem Wechesel des readyState des Requests aufgerufen wird
  function responseHandler(){
    // Erst beim readyState 4 ist der Request vollstaendig abgeschlossen
    if(xmlHttpRequest.readyState < 4){
      return null;
    }
    // Nur bei den HTTP-Status-Code 200 oder 304 war der Request erfolgreich
    if(xmlHttpRequest.status != 200 && xmlHttpRequest.status != 304){
      // Fehlermeldung anzeigen
      _this.errorHandler('Fehler bei AJAX-Request. Status-Code: ' + xmlHttpRequest.status + '. Status-Text: ' + xmlHttpRequest.statusText + '.');
      return null;
    }
    // Nur mit einer successHandler-Methode kann der Request verarbeitet werden
    if(!_this.successHandler){
      // Fehlermeldung anzeigen
      _this.errorHandler('Kein Success-Handler fuer AJAX-Request definiert.');
      return null;
    }
    /* Alle Tests erfolgreich: Der Success-Handler-Methode wird die Plain-Text- und
       die XML-Response bergeben, von denen meist nur eine verarbeitet wird */
    _this.successHandler(xmlHttpRequest.responseText, xmlHttpRequest.responseXML);
  }
}