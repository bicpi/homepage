<?php header('Content-Type: text/html;charset=utf-8'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Beispiel-Navigation</title>
  <meta http-equiv="content-type" content="text/html;charset=utf-8" />
  <script type="text/javascript" language="javascript" src="js/ajaxEngine.js"></script>
  <script type="text/javascript" language="javascript" src="js/JSON.js"></script>
  <script type="text/javascript" language="javascript" src="js/navigation.js"></script>
</head>
<body>
  <h1 id="header"></h1>
  <div id="navigation">
    <a href="#" id="link_1">Link 1</a> |
    <a href="#" id="link_2">Link 2</a> |
    <a href="#" id="link_3">Link 3</a>
  </div>
  <p id="content"></p>
  <div id="footer">&copy; 2009</div>
</body>
</html>