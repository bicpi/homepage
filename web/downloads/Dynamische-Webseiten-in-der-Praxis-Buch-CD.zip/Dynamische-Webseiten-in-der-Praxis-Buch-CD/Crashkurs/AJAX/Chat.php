<?php header('Content-Type: text/html;charset=utf-8'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Chat</title>
  <meta http-equiv="content-type" content="text/html;charset=utf-8" />
  <script type="text/javascript" language="javascript" src="js/ajaxEngine.js"></script>
  <script type="text/javascript" language="javascript" src="js/chat.js"></script>
</head>
<body>
<h1>Test der AJAX-Engine: Chat</h1>
<form action="#" id="chat_form">
  Nachricht: <input type="text" name="message" id="message" />
</form>
<p id="chatbox"></p>
</body>
</html>