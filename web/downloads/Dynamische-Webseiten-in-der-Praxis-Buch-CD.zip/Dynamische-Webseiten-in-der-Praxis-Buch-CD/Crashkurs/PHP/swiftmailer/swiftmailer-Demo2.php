<?php
// swiftmailer/swiftmailer-Demo2.php
require('swiftmailer/swift_required.php');

$transport = Swift_SmtpTransport::newInstance('smtp.example.org', 25)
  ->setUsername('Ihr Benutzername')
  ->setPassword('Ihr Passwort');

$mailer = Swift_Mailer::newInstance($transport);

$message = Swift_Message::newInstance()
  ->setFrom(array('sender@example.org' => 'Absender-Name'))
  ->setTo(array('recipient@example.org'))
  ->setCc(array(
    'mike@mike.com' => 'Michael Zeller',
    'caspar@nagel.de' => 'Caspar'
  ))
  ->setBcc(array(
    'caspar@nagel.de' => 'Caspar',
    'susanne@susonne.net' => 'Susonne'
  ))
  ->setBody('Die Nachricht im Klartext');

$message->addPart('<strong>Die Nachricht im <em>HTML</em>-Format</strong>', 'text/html');

$message->addCc('felicitas@example.org', 'Felicitas');

$message->setSubject('Der Betreff');

$attachment = Swift_Attachment::fromPath('swiftmailer-Demo1.php', 'application/x-httpd-php');  
$message->attach($attachment);
$attachment = Swift_Attachment::fromPath('foto.jpg', 'image/jpg');  
$message->attach($attachment);

printf("%d Nachricht(en) gesendet", $mailer->send($message));
?>