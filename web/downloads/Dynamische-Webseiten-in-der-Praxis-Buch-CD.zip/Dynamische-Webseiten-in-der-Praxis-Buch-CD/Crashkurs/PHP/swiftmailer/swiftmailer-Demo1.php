<?php
// swiftmailer/swiftmailer-Demo1.php
require('swiftmailer/swift_required.php');

$transport = Swift_SmtpTransport::newInstance('smtp.example.org', 25)
  ->setUsername('Ihr Benutzername')
  ->setPassword('Ihr Passwort');

$mailer = Swift_Mailer::newInstance($transport);

$message = Swift_Message::newInstance('Der Betreff')
  ->setFrom(array('sender@example.org' => 'Absender-Name'))
  ->setTo(array('recipient@example.org'))
  ->setBody('Der Nachrichtentext');

printf("%d Nachricht(en) gesendet", $mailer->send($message));
?>