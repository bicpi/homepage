<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Regul&auml;re Ausdr&uuml;cke 7</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// regulaereausdruecke7.php
$string = 'Das ist [b]fett[/b] und das ist [i]kursiv[/i]';
$regs  = array('!\[b\](.+)\[/b\]!', '!\[i\](.+)\[/i\]!');
$reps  = array('<strong>\\1</strong>', '<em>\\1</em>');
$string = preg_replace($regs, $reps, $string);
echo $string;

/* Ausgabe (Quelltext!)
Das ist <strong>fett</strong> und das ist <em>kursiv</em>
*/
?>
</body>
</html>

