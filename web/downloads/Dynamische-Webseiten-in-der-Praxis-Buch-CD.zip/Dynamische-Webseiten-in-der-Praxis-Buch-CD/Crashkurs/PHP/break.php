<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>break</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// break.php
for($i = 1; $i < 11; $i++){
  for($j = 1; $j < 11; $j++){
    if($i == 3){
      break;
    }
    elseif($i == 7){
      break 2;
    }
    echo $i * $j . " \n";
  }
  echo '<br />';
}


/* Ausgabe
1 2 3 4 5 6 7 8 9 10
2 4 6 8 10 12 14 16 18 20

4 8 12 16 20 24 28 32 36 40
5 10 15 20 25 30 35 40 45 50
6 12 18 24 30 36 42 48 54 60
*/
?>
</body>
</html>

