<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>OOP 2</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// oop2.php
class Interaktiv{
  protected $fehler = '';

  protected function arrayElement($array, $schluessel){
    if(array_key_exists($schluessel, $array)){
      return $array[$schluessel];
    }
    return false;
  }

  protected function pruefeLeer($feld, $wert){
    if($wert == '')
      $this->fehler .= "Bitte <em>$feld</em> eingeben.<br />";
  }
}

class Gaestebuch extends Interaktiv{
  private $name;
  private $kommentar;

  public function __construct($titel){
    echo "<h1>$titel</h1>";
    $gaestebuch = $this->arrayElement($_POST, 'gaestebuch');
    if($gaestebuch){
      $this->name = $gaestebuch['name'];
      $this->kommentar = $gaestebuch['kommentar'];
      $this->pruefeLeer('Name', $this->name);
      $this->pruefeLeer('Kommentar', $this->kommentar);
      if($this->fehler){
        echo $this->fehler;
        $this->zeigeForm();
      }
      else{
        $this->zeigeEintrag();
      }
    }
    else{
      $this->zeigeForm();
    }
  }

  private function zeigeEintrag(){
    echo '<strong>Name:</strong><br />' . $this->name . '<br />';
    echo '<strong>Kommentar:</strong><br />' . $this->kommentar;
  }

  private function zeigeForm(){
    echo '<form action="" method="post">
          <strong>Name:</strong><br />
          <input type="text" name="gaestebuch[name]" /><br />
          <strong>Kommentar:</strong><br />
          <textarea name="gaestebuch[kommentar]"></textarea><br />
          <input type="submit" value="Eintragen" /></form>';
  }
}

new Gaestebuch('Mein G&auml;stebuch');
?>
</body>
</html>
