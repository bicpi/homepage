<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Arrays 3</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// arrays3.php
$tomaten = array(array(5, 'Netz'),
                 array('Tomaten', 2.39),
                 'Waehrungen'=>array('DM', 'Euro'));

echo "{$tomaten[0][0]} {$tomaten[1][0]} im {$tomaten[0][1]}
      kosten {$tomaten[1][1]} {$tomaten['Waehrungen'][1]}";

/* Ausgabe
5 Tomaten im Netz kosten 2.39 Euro
*/
?>
</body>
</html>

