<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Datum und Zeit 4</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// datumundzeit4.php
$zs = mktime(18, 45, 0, 6, 9, 2006);
echo date('d.m.Y, H:i:s', $zs) . '<br />';

$zs = mktime(25, 45, 0, 2, 31, 2006);
echo date('d.m.Y, H:i:s', $zs);

/* Ausgabe
09.06.2006, 18:45:00
04.03.2006, 01:45:00
*/
?>
</body>
</html>

