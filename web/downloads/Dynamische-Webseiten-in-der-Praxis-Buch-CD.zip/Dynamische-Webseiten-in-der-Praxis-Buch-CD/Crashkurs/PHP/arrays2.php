<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Arrays 2</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// arrays2.php
$_123[] = 1;
$_123[] = 2;
$_123[] = 3 . '. ';

$detektive['1.Detektiv'] = 'Justus Jonas';
$detektive['2.Detektiv'] = 'Peter Shaw';
$detektive[] = 'Bob Andrews';
echo "$_123[0]. Detektiv: {$detektive['1.Detektiv']} <br />
      $_123[1]. Detektiv: {$detektive['2.Detektiv']} <br />
      $_123[2]Detektiv: $detektive[0]";

/* Ausgabe
1. Detektiv: Justus Jonas
2. Detektiv: Peter Shaw
3. Detektiv: Bob Andrews
*/
?>
</body>
</html>

