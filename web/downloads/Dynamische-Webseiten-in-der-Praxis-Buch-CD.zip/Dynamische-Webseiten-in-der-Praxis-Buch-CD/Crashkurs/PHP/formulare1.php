<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Formulare 1</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// formulare1.php
function arrayElement($array, $schluessel){
  if(array_key_exists($schluessel, $array)){
    return $array[$schluessel];
  }
  return false;
}

$Submit = arrayElement($_POST, 'Submit');
if($Submit){
  $Name          = arrayElement($_POST, 'Name');
  $Adresse       = arrayElement($_POST, 'Adresse');
  $Pizza         = arrayElement($_POST, 'Pizza');
  $Extras1       = arrayElement($_POST, 'Extras1');
  $Extras2       = arrayElement($_POST, 'Extras2');
  $Zahlungsart   = arrayElement($_POST, 'Zahlungsart');
  $Bestellnummer = arrayElement($_POST, 'Bestellnummer');
  echo '<h1>Vielen Dank f&uuml;r Ihre Bestellung</h1>';
  echo '<h3>Uns wurden folgende Daten &uuml;bermittelt:</h3>';
  echo "<p>Name: $Name</p>";
  echo "<p>Adresse: " . nl2br($Adresse) . "</p>";
  echo "<p>Pizza: $Pizza</p>";
  echo "<p>Extras: $Extras1 $Extras2</p>";
  echo "<p>Zahlungsart: $Zahlungsart</p>";
  echo "<p>Bestellnummer: $Bestellnummer</p>";
  die('</body></html>');
}
?>
<h1>Pizzabestellung</h1>
<form action="" method="post">
<table>
  <tr>
    <td>Name</td>
    <td><input type="text" name="Name" /></td>
  </tr>
  <tr>
    <td>Adresse</td>
    <td><textarea name="Adresse" rows="3" cols="50"></textarea></td>
  </tr>
  <tr>
    <td>Pizza</td>
    <td>
    <select name="Pizza">
      <option>Margherita</option>
      <option>Funghi</option>
      <option>Salami</option>
      <option>Prosciutto</option>
    </select>
    </td>
  </tr>
  <tr>
    <td>Extras</td>
    <td>
    <input type="checkbox" name="Extras1" value="Artischocken" />Artischocken<br />
    <input type="checkbox" name="Extras2" value="Sardellen" />Sardellen<br />
    </td>
  </tr>
  <tr>
    <td>Zahlungsart</td>
    <td>
    <input type="radio" name="Zahlungsart" value="EC" /> EC<br />
    <input type="radio" name="Zahlungsart" value="Bar" checked="checked" /> Bar
    </td>
  </tr>
  <tr>
    <td colspan="2">
    <input type="hidden" name="Bestellnummer" value="242" />
    <input type="submit" name="Submit" value="Bestellen" />
    </td>
  </tr>
</table>
</form>
</body>
</html>
