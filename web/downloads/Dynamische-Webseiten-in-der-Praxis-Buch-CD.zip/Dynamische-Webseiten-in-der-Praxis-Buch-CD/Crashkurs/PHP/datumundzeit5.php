<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Datum und Zeit 5</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// datumundzeit5.php
echo microtime() . '<br />';
echo microtime(true);

/* Ausgabe (z.B.)
0.45383100 1130706760
1130706760.4539
*/
?>
</body>
</html>

