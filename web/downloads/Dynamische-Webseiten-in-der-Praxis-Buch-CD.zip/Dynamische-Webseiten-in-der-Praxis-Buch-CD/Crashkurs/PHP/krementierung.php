<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>In- und Dekrementierung</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// krementierung.php
$i = 1;
$i++;
++$i;
echo "i:$i, ";
$i--;
--$i;
echo "i:$i, ";
echo 'i:' . ++$i . ', ';
echo 'i:' . $i++ . ', ';
echo "i:$i, ";
$a = --$i;
$b = $i--;
echo "a:$a, b:$b, i:$i";

/* Ausgabe
i:3, i:1, i:2, i:2, i:3, a:2, b:2, i:1
*/
?>
</body>
</html>

