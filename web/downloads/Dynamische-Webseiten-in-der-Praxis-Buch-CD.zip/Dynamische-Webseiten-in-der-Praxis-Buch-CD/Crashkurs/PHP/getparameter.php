<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>GET-Parameter</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// getparameter.php
function arrayElement($array, $schluessel){
  if(array_key_exists($schluessel, $array)){
    return $array[$schluessel];
  }
  return false;
}

$menuepunkte = array('Home', 'Interaktiv', 'Galerie');
foreach($menuepunkte as $wert){
  $wert = '<a href="' . $_SERVER['PHP_SELF'] .
                   "?wahl=$wert\">$wert</a>";
  echo $wert . '&nbsp;';
}
echo '<p>&nbsp;</p>';

$wahl = arrayElement($_GET, 'wahl');
switch($wahl){
  case 'Home':
    echo "Hier die Inhalte des Men&uuml;punkts 'Home'.";
    break;
  case 'Interaktiv':
    echo "Hier die Inhalte des Men&uuml;punkts 'Interaktiv'.";
    break;
  case 'Galerie':
    echo "Hier die Inhalte des Men&uuml;punkts 'Galerie'.";
    break;
  default:
    echo "Willkommen auf unserer Website.<br />
          Bitte w&auml;hlen Sie aus dem Men&uuml;.";
}
?>
</body>
</html>
