<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Funktionen 6</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// funktionen6.php
function sperrdruck($string){
  $neuer_string = '';
  for($i = 0; $i < strlen($string); $i++){
    $neuer_string .= substr($string, $i, 1) . ' ';
  }
  return $neuer_string;
}

$wort = sperrdruck('Sattelschlepper');
echo "$wort";

/* Ausgabe
S a t t e l s c h l e p p e r
*/
?>
</body>
</html>

