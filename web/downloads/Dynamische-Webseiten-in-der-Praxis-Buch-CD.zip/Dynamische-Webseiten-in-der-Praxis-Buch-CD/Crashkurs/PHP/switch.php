<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>switch</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// switch.php
$aktion = 'laufen';
switch($aktion){
  case 'stehen':
    echo 'Ich stehe.';
    break;
  case 'gehen':
    echo 'Ich gehe.';
    break;
  case 'laufen':
    echo 'Ich laufe.';
    break;
  default:
    echo 'Ich weiss nicht was ich mache.';
}

/* Ausgabe
Ich laufe.
*/
?>
</body>
</html>

