<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Formulare 2</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// formulare2.php
function arrayElement($array, $schluessel){
  if(array_key_exists($schluessel, $array)){
    return $array[$schluessel];
  }
  return false;
}

$mitarbeiter = arrayElement($_POST, 'mitarbeiter');
if($mitarbeiter){
  echo $mitarbeiter['Vorname'] . '<br />';
  echo $mitarbeiter['Name'] . '<br />';
  echo $mitarbeiter['Wohnort'] . '<br />';
  exit();
}
?>
<h1>Mitarbeiter</h1>
<form action="" method="post">
Vorname: <input type="text" name="mitarbeiter[Vorname]" /><br />
Name: <input type="text" name="mitarbeiter[Name]" /><br />
Wohnort: <input type="text" name="mitarbeiter[Wohnort]" />
<input type="submit" value="Los" />
</form>
</body>
</html>
