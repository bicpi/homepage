<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title></title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// oop-Fahrzeug.php
class Fahrzeug{
  public $farbe;
  public $hoechstgeschw;
  public $geschw;
  public $raeder;
  private $licht = false;
  
  // Um $x km/h beschleunigen
  public function beschleunigen($x){
    $this->geschw += $x;
    if($this->geschw >= $this->hoechstgeschw){
      $this->geschw = $this->hoechstgeschw;
      echo 'H&ouml;chstgeschwindigkeit erreicht: ' . 
            $this->geschw . ' km/h<br />';
    }
    else{
      echo 'Aktuelle Geschwindigkeit: ' . $this->geschw . 
           ' km/h<br />';
    }
  }

  // Um $x km/h bremsen
  public function bremsen($x){
    $this->geschw -= $x;
    if($this->geschw <= 0){
      $this->geschw = 0;
      echo 'Fahrzeug steht: 0 km/h<br />';
    }
    else{
      echo 'Aktuelle Geschwindigkeit: ' . $this->geschw . 
           ' km/h<br />';
    }
  }

  public function lichtSchalten(){
    $this->licht = !$this->licht;
    if($this->licht)
      echo 'Licht ist an<br />';
    else
      echo 'Licht ist aus<br />';
  }
}

class PKW extends Fahrzeug{
  private $warnblinker = false;
  
  public function warnblinkerSchalten(){
    $this->warnblinker = !$this->warnblinker;
    if($this->warnblinker)
      echo 'Warnblinker ist an<br />';
    else
      echo 'Warnblinker ist aus<br />';
  }
}

class Fahrrad extends Fahrzeug{
  public $rahmenhoehe = 26; // Zoll
  private $sattelhoehe = 0; // cm ab Rahmenhoehe
  public $sattelhoechsthoehe;
  
  public function sattelErhoehen(){
    $this->sattelhoehe += 1;
    if($this->sattelhoehe > $this->sattelhoechsthoehe){
      $this->sattelhoehe = $this->sattelhoechhoehe;
    }
  }

  public function sattelErniediregen(){
    $this->sattelhoehe -= 1;
    if($this->sattelhoehe < 0){
      $this->sattelhoehe = 0;
    }
  }

  public function sattelhoeheAusgeben(){
    echo 'Sattelh&ouml;he: ' . $this->sattelhoehe . ' cm<br />';
  }
}

$ObjFahrrad = new Fahrrad();
$ObjPKW = new PKW();

$ObjFahrrad->raeder = 2;
$ObjFahrrad->hoechstgeschw = 40;
$ObjFahrrad->beschleunigen(22);
$ObjFahrrad->sattelhoechsthoehe = 10;
for($i = 1; $i < 7; $i++)
  $ObjFahrrad->sattelErhoehen();
$ObjFahrrad->sattelhoeheAusgeben();
echo 'R&auml;der: ' . $ObjFahrrad->raeder;
echo '<p>&nbsp</p>';
$ObjPKW->raeder = 4;
$ObjPKW->hoechstgeschw = 240;
$ObjPKW->beschleunigen(172);
$ObjPKW->warnblinkerSchalten();
$ObjPKW->bremsen(200);
?>
</body>
</html>
