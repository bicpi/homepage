<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Operatoren 2</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// operatoren2.php
$x = 6;
$y = 3;
$x += $y;
$x /= $y;
$x *= 6;
$x %= 5;
$x -= 4;
echo $x;

/* Ausgabe
-1
*/
?>
</body>
</html>

