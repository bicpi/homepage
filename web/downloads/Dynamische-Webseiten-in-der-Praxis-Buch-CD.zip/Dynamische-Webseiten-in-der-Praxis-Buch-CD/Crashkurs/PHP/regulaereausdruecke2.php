<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Regul&auml;re Ausdr&uuml;cke 2</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// regulaereausdruecke2.php
$string = '233347789';
echo preg_match('!^.$!', $string) . ', ';
echo preg_match('!^.*$!', $string) . ', ';
echo preg_match('!^23{4,}.+$!', $string) . ', ';
echo preg_match('!^1?2?3{1,3}47+.92*$!', $string);

/* Ausgabe
0, 1, 0, 1
*/
?>
</body>
</html>

