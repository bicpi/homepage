<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Funktionen 7</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// funktionen7.php
function maskieren($wert){
  if(is_array($wert))
    foreach($wert as $key=>$value){
      $wert[$key] = maskieren($value);
    }
  else
    $wert = addslashes($wert);
  return $wert;
}

$array1 = array("Wie geht's?", "Wie geht's?");
$array2 = array("Wie geht's?", $array1);
$array3 = array("Wie geht's?", $array2);
$array3 = maskieren($array3);

echo '<pre>';
print_r($array3);
echo '</pre>';

/* Ausgabe
Array
(
    [0] => Wie geht\'s?
    [1] => Array
        (
            [0] => Wie geht\'s?
            [1] => Array
                (
                    [0] => Wie geht\'s?
                    [1] => Wie geht\'s?
                )

        )

)
*/
?>
</body>
</html>

