<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Dateien 3</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// dateien3.php
$datei = 'test.txt';
$string = "Zeile1\nZeile2\nZeile3\nZeile4";
$dh = fopen($datei, 'w+');
fwrite($dh, $string);
rewind($dh);
while($zeile = fgets($dh))
  echo nl2br($zeile);
fclose($dh);

/* Ausgabe:
Zeile1
Zeile2
Zeile3
Zeile4
*/
?>
</body>
</html>

