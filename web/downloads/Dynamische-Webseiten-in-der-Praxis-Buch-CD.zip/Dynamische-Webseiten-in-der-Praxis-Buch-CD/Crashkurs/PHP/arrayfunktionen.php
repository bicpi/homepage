<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Arrayfunktionen</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// arrayfunktionen.php
$array1 = array('The Strokes', 'Coldplay', 'Starsailor');
$string = implode(', ', $array1);
echo $string . '<br />';

$string = 'Embrace, New Model Army, Oasis';
$array2 = explode(', ', $string);
echo '<pre>';
print_r($array2);
echo '</pre>';

if(in_array('Embrace', $array2)){
  echo '"Embrace" wurde im Array gefunden.<br />';
}

list($band1, $band2, $band3) = $array1;
echo "$band1/$band2/$band3";

$array3 = array_merge($array1, $array2);
array_unshift($array3, 'Tocotronic');
echo '<pre>';
print_r($array3);
echo '</pre>';

$index = array_rand($array1); // Zufallsindex
echo $array1[$index];

sort($array3);
echo '<pre>';
print_r($array3);
echo '</pre>';
?>
</body>
</html>

