<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>OOP 6</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// oop6.php
class Quadrat{
  private $breite = 0;
  private $laenge = 0;

  public function __set($eigenschaft, $wert){
    switch($eigenschaft){
      case 'x':
        if(is_numeric($wert))
          $this->breite = (int)$wert;
        else
          echo "<em>$wert</em> muss numerisch sein.<br />";
        break;
      case 'y':
        if(is_numeric($wert))
          $this->laenge = (int)$wert;
        else
          echo "<em>$wert</em> muss numerisch sein.<br />";
        break;
      case 'xy':
        $xy = preg_split('!;!', $wert);
        if(count($xy) != 2){
          echo 'Werte m&uuml;ssen im Format "x;y" eingegeben werden.<br />';
          return;
        }
        if(!is_numeric($xy[0]) || !is_numeric($xy[1])){
          echo 'x und y m&uuml;ssen numerisch sein.<br />';
          return;
        }
        $this->breite = (int)$xy[0];
        $this->laenge  = (int)$xy[1];
    }
  }

  public function __get($eigenschaft){
    switch($eigenschaft){
      case 'xy':
        echo "Breite/Laenge: $this->breite;$this->laenge<br />";
        break;
      case 'flaeche':
        echo 'Fl&auml;che: ' . ($this->breite*$this->laenge) . '<br />';
        break;
      case 'umfang':
        echo 'Umfang: ' . (2*$this->breite+2*$this->laenge) . '<br />';
    }
  }
}

$Objekt = new Quadrat();
$Objekt->xy = '2;3';
echo $Objekt->flaeche;
$Objekt->xy = 'Quatsch';
$Objekt->x = '5';
echo $Objekt->flaeche;
$Objekt->y = 'Schmarrn';
$Objekt->y = '5';
echo $Objekt->xy;
echo $Objekt->umfang;

/* Ausgabe (Quelltext):
Fl&auml;che: 6<br />
Werte m&uuml;ssen im Format "x;y" eingegeben werden.<br />
Flaeche: 15<br />
Schmarrn muss numerisch sein.<br />
Breite/Laenge: 5;5<br />
Umfang: 20<br />
*/
?>
</body>
</html>
