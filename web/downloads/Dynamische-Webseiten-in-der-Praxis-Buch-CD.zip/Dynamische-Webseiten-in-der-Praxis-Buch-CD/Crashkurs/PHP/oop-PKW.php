<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title></title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// oop-PKW.php
class PKW{
  public $farbe;
  public $hoechstgeschw;
  public $geschw;
  public $raeder = 4;
  private $licht = false;
  
  // Um $x km/h beschleunigen
  public function beschleunigen($x){
    $this->geschw += $x;
    if($this->geschw >= $this->hoechstgeschw){
      $this->geschw = $this->hoechstgeschw;
      echo 'H&ouml;chstgeschwindigkeit erreicht: ' . 
            $this->geschw . ' km/h<br />';
    }
    else{
      echo 'Aktuelle Geschwindigkeit: ' . $this->geschw . 
           ' km/h<br />';
    }
  }

  // Um $x km/h bremsen
  public function bremsen($x){
    $this->geschw -= $x;
    if($this->geschw <= 0){
      $this->geschw = 0;
      echo 'Fahrzeug steht: 0 km/h<br />';
    }
    else{
      echo 'Aktuelle Geschwindigkeit: ' . $this->geschw . 
           ' km/h<br />';
    }
  }

  public function lichtSchalten(){
    $this->licht = !$this->licht;
    if($this->licht)
      echo 'Licht ist an<br />';
    else
      echo 'Licht ist aus<br />';
  }
}

$Objekt = new PKW();
$Objekt->hoechstgeschw = 190;
$Objekt->farbe = 'blau';
$Objekt->beschleunigen(20);
$Objekt->bremsen(50);
$Objekt->beschleunigen(220);
$Objekt->lichtSchalten();
$Objekt->lichtSchalten();
?>
</body>
</html>
