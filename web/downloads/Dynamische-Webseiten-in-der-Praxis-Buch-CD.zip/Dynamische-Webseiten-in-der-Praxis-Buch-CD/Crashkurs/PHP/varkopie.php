<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Variablenkopie</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// varkopie.php
$erste_variable  = 'Ich esse gerne Pizza.';
$zweite_variable = 'Ich esse gerne Fisch.';
$dritte_variable = $erste_variable . '<br />';
echo $dritte_variable;
$dritte_variable = $zweite_variable;
echo $dritte_variable;

/* Ausgabe
Ich esse gerne Pizza.
Ich esse gerne Fisch.
*/
?>
</body>
</html>

