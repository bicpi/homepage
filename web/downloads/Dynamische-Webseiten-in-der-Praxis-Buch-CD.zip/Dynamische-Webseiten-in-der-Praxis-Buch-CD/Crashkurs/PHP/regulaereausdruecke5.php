<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Regul&auml;re Ausdr&uuml;cke 5</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// regulaereausdruecke5.php
echo preg_match('!^\d$!', '4') . ', ';
echo preg_match('!^\d$!', '46') . ', ';
echo preg_match('!^\s+$!', "\n\t") . ', ';
echo preg_match('!^\w+$!', 'Hallo!') . ', ';
echo preg_match('!\bPHP\b!', 'PHP ist toll!');

/* Ausgabe
1, 0, 1, 0, 1
*/
?>
</body>
</html>

