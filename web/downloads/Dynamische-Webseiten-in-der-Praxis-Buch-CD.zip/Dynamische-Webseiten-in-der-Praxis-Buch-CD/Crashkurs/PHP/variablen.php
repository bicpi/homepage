<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Variablen</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// variablen.php
$string  = 'Das ist ein String (= Zeichenkette)';
$integer = 8;            // Ganzzahl
$double  = 2.34;         // Fliesskommazahl
$bool    = true;         // Wahrheitswert
$null    = NULL;         // Das Nichts

class Objekt{};
$Objekt  = new Objekt(); // Instanz einer Klasse

//  Container fuer alle Arten von Datentypen
$array   = array($string, $integer, $double, $bool, $Objekt, $null);

echo gettype($string) . ', ';
echo gettype($integer) . ', ';
echo gettype($double) . ', ';
echo gettype($bool) . ', ';
echo gettype($null) . ', ';
echo gettype($Objekt) . ', ';
echo gettype($array);
?>
</body>
</html>

