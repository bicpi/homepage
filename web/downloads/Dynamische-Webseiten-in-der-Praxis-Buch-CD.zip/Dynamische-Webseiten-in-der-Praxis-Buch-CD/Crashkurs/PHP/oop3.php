<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>OOP 3</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// oop3.php
class Testklasse{
  public function __destruct(){
    echo 'Objekt wurde zerstoert.';
  }
}
new Testklasse();

/* Ausgabe
Objekt wurde zerstoert.
*/
?>
</body>
</html>
