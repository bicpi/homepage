<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Funktionen 4</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// funktionen4.php
function schreibeText($text, $groesse = 1, $farbe = 'FF0000'){
  echo "<h$groesse style=\"color:#$farbe\">$text</h$groesse>\n";
}

schreibeText('Wir programmieren PHP');
schreibeText('PHP macht Spa&szlig;', 3, '000033');

/* Ausgabe (Quellcode!)
<h1 style="color:#FF0000">Wir programmieren PHP</h1>
<h3 style="color:#000033">PHP macht Spa&szlig;</h3>
*/
?>
</body>
</html>

