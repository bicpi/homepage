<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>foreach</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// foreach.php
$array = array(1, 2, 3);
echo '<p>';
foreach($array as $wert){
  echo $wert;
}
echo '</p>';

$array = array('Vorname'=>'Elisabeth',
               'Nachname'=>'von Butter',
               'Wohnort'=>'Berlin');
foreach($array as $schluessel=>$wert){
  echo "$schluessel: $wert<br />";
}


/* Ausgabe
123

Vorname: Elisabeth
Nachname: von Butter
Wohnort: Berlin
*/
?>
</body>
</html>

