<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>for</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
class Foo{
  public $bar = 0;
}
$foo1 = new Foo();
$foo2 = $foo1;
$foo3 = clone $foo1;
$foo2->bar = 100;
echo '<p>$foo1->bar: ' . $foo1->bar . '; $foo3->bar: ' . $foo3->bar . '</p>';

function myFunction($obj, $value){
  $obj->bar = $value;
}
myFunction($foo2, 99);
echo '<p>$foo1->bar: ' . $foo1->bar  . '</p>';
myFunction(clone $foo2, 50);
echo '<p>$foo1->bar: ' . $foo1->bar  . '</p>';

/* Ausgabe
$foo1->bar: 100; $foo3->bar: 0
$foo1->bar: 99
$foo1->bar: 99
*/
?>
</body>
</html>