<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Regul&auml;re Ausdr&uuml;cke 4</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// regulaereausdruecke4.php
$string = 'Prof. Forstmann isst 2 Bananen';
echo preg_match('!^(Dr)|(Prof)\. [a-zA-Z]+ isst [2-9]{1} Bananen$!', 
                $string) . ', ';
echo preg_match('!^[a-zA-Z0-9]*$!', $string) . ', ';
echo preg_match('!^[a-zA-Z0-9\. ]*$!', $string);

/* Ausgabe
1, 0, 1
*/
?>
</body>
</html>

