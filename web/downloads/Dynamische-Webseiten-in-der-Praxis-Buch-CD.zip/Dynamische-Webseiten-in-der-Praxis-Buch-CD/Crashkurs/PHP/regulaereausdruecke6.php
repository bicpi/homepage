<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Regul&auml;re Ausdr&uuml;cke 6</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// regulaereausdruecke6.php
$daten = 'Geboren am 06/24/1938, gestorben am 02/12/2005.';
$daten = preg_replace('!\b(\d{2})/(\d{2})/(\d{4})\b!', '\\2.\\1.\\3', $daten);
echo $daten;

/* Ausgabe
Geboren am 24.06.1938, gestorben am 12.02.2005.
*/
?>
</body>
</html>

