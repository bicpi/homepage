<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Regul&auml;re Ausdr&uuml;cke 8</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// regulaereausdruecke8.php
$string = 'Das ist [i]kursiv[/i] und [i]das auch[/i] und [I]das[/I]';
$string = preg_replace('!\[i\](.+)\[/i\]!', '<em>\\1</em>', $string);
echo $string;

/* Ausgabe (Quelltext!)
Das ist <em>kursiv[/i] und [i]das auch</em> und [I]das[/I]
*/
?>
</body>
</html>

