<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Arrays 1</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// arrays1.php
$zahlen = array(1, 'Zwei', 3);
echo $zahlen[0] . ', ' . $zahlen[1] . ', ' . $zahlen[2] . 
     '<br />';

$essen = array('Gemuese'=>'Tomate', 'Obst'=>'Apfel',
               123=>'Schoko-Eis');
echo $essen['Gemuese'] . ' mit ' . $essen['Obst'] . ' und ' .
     $essen[123] . ' - lecker!';

/* Ausgabe
1, Zwei, 3
Tomate mit Apfel und Schoko-Eis - lecker!
*/
?>
</body>
</html>
