<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Zeichenketten</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// zeichenketten.php
$string = 'Alle lieben PHP';

echo strlen($string) . '<br />';
echo strtoupper($string) . '<br />';
$pos = strpos($string, 'PHP');
echo substr($string, $pos, 3) . '<br />';
echo substr($string, -3) . '<br />';
echo strstr($string, 'P') . '<br />';
echo str_replace('PHP', 'MySQL', $string);

/* Ausgabe
15
ALLE LIEBEN PHP
PHP
PHP
PHP
Alle lieben MySQL
*/
?>
</body>
</html>

