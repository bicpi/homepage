<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Regul&auml;re Ausdr&uuml;cke 9</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// regulaereausdruecke9.php
$string = 'Das ist [i]kursiv[/i] und [i]das auch[/i] und [I]das[/I]';
$string = preg_replace('!\[i\](.+)\[/i\]!Ui', '<em>\\1</em>', $string);
echo $string;

/* Ausgabe (Quelltext!)
Das ist <em>kursiv</em> und <em>das auch</em> und <em>das</em>
*/
?>
</body>
</html>

