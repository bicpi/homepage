<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>Variablenexistenz: isset() und empty()</title>
  <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
</head>
<body>
<?php
// variablenexistenz.php
if(isset($a)) echo '$a gesetzt<br />';
else echo '$a nicht gesetzt<br />';
if(empty($a)) echo '$a leer<br /><br />';
else echo '$a nicht leer<br /><br />';
// $a nicht gesetzt
// $a leer

$a = 'Elephant';
if(isset($a)) echo '$a gesetzt<br />';
else echo '$a nicht gesetzt<br />';
if(empty($a)) echo '$a leer<br /><br />';
else echo '$a nicht leer<br /><br />';
// $a gesetzt
// $a nicht leer

$a = 0;
if(isset($a)) echo '$a gesetzt<br />';
else echo '$a nicht gesetzt<br />';
if(empty($a)) echo '$a leer<br /><br />';
else echo '$a nicht leer<br /><br />';
// $a gesetzt
// $a leer

$a = '0';
if(isset($a)) echo '$a gesetzt<br />';
else echo '$a nicht gesetzt<br />';
if(empty($a)) echo '$a leer<br /><br />';
else echo '$a nicht leer<br /><br />';
// $a gesetzt
// $a leer

$a = 1;
if(isset($a)) echo '$a gesetzt<br />';
else echo '$a nicht gesetzt<br />';
if(empty($a)) echo '$a leer<br /><br />';
else echo '$a nicht leer<br /><br />';
// $a gesetzt
// $a nicht leer

$a = '';
if(isset($a)) echo '$a gesetzt<br />';
else echo '$a nicht gesetzt<br />';
if(empty($a)) echo '$a leer<br /><br />';
else echo '$a nicht leer<br /><br />';
// $a gesetzt
// $a leer

unset($a);
if(isset($a)) echo '$a gesetzt<br />';
else echo '$a nicht gesetzt<br />';
if(empty($a)) echo '$a leer<br /><br />';
else echo '$a nicht leer<br /><br />';
// $a nicht gesetzt
// $a leer

$a = NULL;
if(isset($a)) echo '$a gesetzt<br />';
else echo '$a nicht gesetzt<br />';
if(empty($a)) echo '$a leer<br /><br />';
else echo '$a nicht leer<br /><br />';
// $a nicht gesetzt
// $a leer
?>

</body>
</html>
