<?php
// zahler.php

/* Besucherzaehler */

$ip           = getenv("REMOTE_ADDR");   // Besucher-IP
$zeitstempel  = microtime(true);         // Mikrozeit
$zaehlerdatei = "zaehler/zaehler.txt";   // Datei mit Zaehlerstand
$blockzeit    = 10 ;                  // Besucher-Blockzeit; 30 Min.
$sperrverz    = 'zaehler/sperrdateien/'; // Verzeichnis mit gesperrten Zeitstempel/IP-Dateien

$dh  = opendir($sperrverz); // Verzeichnis mir Zeitstempel/IP-Dateien oeffnen
$ips = array();             // Array, in den alle zu blockenden IPs kommen

while(gettype($datei = readdir($dh)) != "boolean"){ // Verzeichnis durchlaufen
  if($datei == '.' || $datei == '..'){ // Spezialfiles auslassen
    continue;
  }
  // Falls Dateiname (=Zeitstempel) groesser als aktuelle Zeit minus Blockzeit,
  // dann IP auslesen und in den Array "$ips" stecken. Diese IP darf nicht
  // gezaehlt werden (s.u.)
  if(floatval($datei) > floatval($zeitstempel-$blockzeit)){
    $dh2    = fopen($sperrverz . $datei, "r"); // Datei oeffnen
    $tmp_ip = fread($dh2, filesize($sperrverz . $datei));    // Datei lesen
    fclose($dh2);      // Datei schliessen
    $ips[]  = $tmp_ip; // IP aus File an "$ips" anfuegen
  }
  else{ // falls Dateiname kleiner aktuelle Zeit minus Blockzeit
    unlink($sperrverz . $datei); // File loeschen
  }
}

$dh         = fopen($zaehlerdatei, "r+");          // Counterstandfile oeffnen
$zaehlstand = fread($dh, filesize($zaehlerdatei)); // Counterstand auslesen


// Falls Besucher-IP nicht in "$ips" vorkommt, den Zaehlerstand um eins erhoehen,
// neu in die Zaehlerdatei schreiben und eine Zeitstempel/IP-Datei fuer diesen
// Besucher anlegen, damit er nicht erneut gezaehlt wird.
if(!in_array($ip, $ips)){
  rewind($dh);   // Datei nach Auslesen zurueckspulen
  $zaehlstand++; // Counterstand inkrementieren
  fwrite($dh, $zaehlstand); // Neuen Counterstand schreiben
  $dh2 = fopen($sperrverz . $zeitstempel, "w+"); // Neue Zeitstempel/IP-Datei anlegen
  fwrite($dh2, $ip); // IP in Datei mit aktuellem Zeitstempel als Namen schreiben
  fclose($dh2);
}
fclose($dh);

for($i = 0; $i < 10; $i++){
  $zaehlstand = preg_replace("!$i!", "$i~", $zaehlstand);
}

for($i = 0; $i < 10; $i++){
  $zaehlstand = preg_replace("!$i~!", 
                             '<img src="zaehler/layout/' . $i . '.gif" width="28" height="28">', 
                             $zaehlstand);
}
echo '<img src="zaehler/layout/links.gif" width="15" height="28">' . $zaehlstand . '<img src="zaehler/layout/rechts.gif" width="15" height="28">'; // Zaehlstand ausgeben
?> 