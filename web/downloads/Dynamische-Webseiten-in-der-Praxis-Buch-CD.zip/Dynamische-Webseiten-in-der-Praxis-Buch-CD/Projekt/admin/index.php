<?php
/**
* Datei-Ort : /admin/index.php
* Zweck     : Hauptindexdatei der Administrationsoberflaeche
* Autor (c) : Philipp Rieber / webflips
* Website   : http://www.webflips.de
* Kontakt   : info@webflips.de
* Datum     : 03.08.2009
* Version   : 3.0
*/



// Zeichensatz festlegen
header('Content-Type: text/html; charset=iso-8859-1');

// Konfigurationsdatei einbinden
require_once('../konf/konf.ink.php');


// Kommentar siehe Hauptindexdatei "/index2.php"
function __autoload($klasse){
  require_once('../klassen/' . $klasse . '.klasse.php');
}


// Kommentar siehe Hauptindexdatei "/index2.php"
$dbh = new MySQL(DBHOST, DBBENUTZER, DBPASSWORT, DBNAME, MYSQL_EXT);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- Doctype (muss in erster Ausgabezeile stehen) -->

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <title>webflips.de *** Administrationsbereich f&uuml;r <?php echo SERVERNAME; ?></title>
  <!-- Zeichensatz -->
  <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
  <!-- CSS-Datei mit allgemeinen und speziellen Layout-Anweisungen -->
  <link rel="stylesheet" href="css/basis.css" type="text/css" media="all" />
</head>

<body>

<?php
// Hauptmenuepunkte
$hauptmenue = array('Menuepunkte' => 'Men&uuml;punkte',
                    'Fussleistenmenue' => 'Fu&szlig;leistenmen&uuml;',
                    'Module' => 'Module',
                    'Farbthemen' => 'Farbthemen',
                    'Installation' => 'Tabellen-Installation');
?>

<div id="menue">
  <?php
  // phpMyAdmin-Link
  echo '<div class="menueelement">' .
       Basis::baueLink('phpmyadmin', 'phpMyAdmin') .
       "</div>\n";

   // Menuepunkte ausgeben
  foreach($hauptmenue as $schluessel=>$wert){
    echo '<div class="menueelement">' .
         Basis::baueLink($_SERVER['PHP_SELF'] , $wert, 'wahl=' . $schluessel) .
         "</div>\n";
  }
  ?>
</div>

<!-- 60px Abstand des div-Kastens zu allen Seiten -->
<div style="margin:60px;">
  <?php
  // Zum Menuepunkt geh�rigen Klassennamen aus dem $_GET-Array holen
  $wahl  = Basis::arrayElement($_GET, 'wahl');

  if(!$wahl || !array_key_exists($wahl, $hauptmenue)){
    echo '<h3>Willkommen im Verwaltungsbereich !</h3>' .
         '<h4>Bitte w&auml;hlen Sie aus den obigen Punkten.</h4>';
    die('</div></body></html>');
  }

  $klassenname = "Admin$wahl";

  // Neues Objekt erzeugen und durch "echo $Objekt" die "__toString()"-Methode
  //aufrufen; dabei den Datenbank-Handle und den Klassennamen in "wahl" uebergeben
  echo new $klassenname($dbh, $wahl);



  // Datenbankverbindung schlie�en
  unset($dbh);
  ?>
</div>

</body>
</html>

