<?php
$cfg['blowfish_secret'] = 'Ihre Passphrase hier';
$i = 0;
$i++;
$cfg['Servers'][$i]['auth_type'] = 'cookie';

