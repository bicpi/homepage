<?php
/**
* Datei-Ort : /admin/phpinfo.php
* Zweck     : Gibt Infos ueber die PHP-Installation aus
* Autor (c) : Philipp Rieber / webflips
* Website   : http://www.webflips.de
* Kontakt   : info@webflips.de
* Datum     : 03.08.2009
* Version   : 3.0
*/



phpinfo();
?>
